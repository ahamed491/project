package Appn;

public class MsgForm
{
	public String from,subject,date,size,msg,sp;
}