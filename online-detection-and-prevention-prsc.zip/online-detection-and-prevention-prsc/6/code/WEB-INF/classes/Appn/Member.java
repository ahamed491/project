package Appn;
	public class Member
	{
		
	public	String name,id,pwd,secq,seca;
	}