import java.sql.Savepoint;

import javax.security.sasl.SaslClientFactory;
import javax.security.sasl.SaslServerFactory;
/*
 * Created on Apr 8, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author user
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class sample implements SaslClientFactory, SaslServerFactory, Savepoint {

	public static void main(String[] args) {
	}
}
